﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using WebFoodAPI.Models;

namespace WebFoodAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly DbappFoodContext _context;
        private readonly IConfiguration _configuration;

        public UserController(DbappFoodContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }

        // Helper: Lấy userId từ token (ưu tiên claim là số)
        private int? GetUserIdFromClaims()
        {
            // Lấy tất cả claim có type là ClaimTypes.NameIdentifier
            var nameIdClaims = User.Claims
                .Where(c => c.Type == ClaimTypes.NameIdentifier)
                .Select(c => c.Value)
                .ToList();

            // Tìm claim nào là số (userId)
            string? userIdString = nameIdClaims.FirstOrDefault(v => int.TryParse(v, out _));

            // Nếu không có, thử lấy từ "nameid"
            userIdString ??= User.FindFirstValue("nameid");

            if (string.IsNullOrEmpty(userIdString) || !int.TryParse(userIdString, out var userId))
            {
                foreach (var claim in User.Claims)
                {
                    Console.WriteLine($"{claim.Type}: {claim.Value}");
                }
                return null;
            }
            return userId;
        }

        // GET: api/User
        [HttpGet]
        // [Authorize(Roles = "admin")]
        public async Task<ActionResult<IEnumerable<UserDTO>>> GetUsers()
        {
            var users = await _context.Users.ToListAsync();
            var usersDto = users.Select(u => UserToDto(u)).ToList();
            return usersDto;
        }

        // GET: api/User/me
        [HttpGet("me")]
        [Authorize]
        public async Task<ActionResult<UserDTO>> GetCurrentUser()
        {
            var userId = GetUserIdFromClaims();
            if (userId == null)
            {
                return Unauthorized(new { message = "Token không hợp lệ hoặc thiếu thông tin người dùng." });
            }

            var user = await _context.Users.FindAsync(userId.Value);
            if (user == null)
            {
                return NotFound(new { message = "Người dùng không tồn tại." });
            }
            return UserToDto(user);
        }

        // GET: api/User/5
        [HttpGet("{id}")]
        public async Task<ActionResult<UserDTO>> GetUser(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user == null)
                return NotFound();
            return UserToDto(user);
        }

        // POST: api/User
        [HttpPost]
        public async Task<ActionResult<UserDTO>> PostUser(UserCreateDTO userCreateDto)
        {
            if (await _context.Users.AnyAsync(u => u.Email == userCreateDto.Email))
                return BadRequest(new { message = "Email đã tồn tại." });

            var user = new User
            {
                Name = userCreateDto.Name,
                Email = userCreateDto.Email,
                Role = string.IsNullOrEmpty(userCreateDto.Role) ? "user" : userCreateDto.Role,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(userCreateDto.Password)
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            var userDto = UserToDto(user);
            return CreatedAtAction(nameof(GetUser), new { id = user.Id }, userDto);
        }

        // POST: api/User/login
        [HttpPost("login")]
        public async Task<ActionResult<object>> Login([FromBody] LoginDTO loginDto)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == loginDto.Email);
            if (user == null)
                return Unauthorized(new { message = "Email không tồn tại!" });

            if (!BCrypt.Net.BCrypt.Verify(loginDto.Password, user.PasswordHash))
                return Unauthorized(new { message = "Sai mật khẩu!" });

            var tokenString = GenerateJwtToken(user);
            var expiresInSeconds = 3600;

            return Ok(new
            {
                token = tokenString,
                expiresIn = expiresInSeconds,
                user = UserToDto(user)
            });
        }

        private string GenerateJwtToken(User user)
        {
            var jwtKey = _configuration["Jwt:Key"];
            if (string.IsNullOrEmpty(jwtKey) || jwtKey.Length < 16)
            {
                throw new InvalidOperationException("Khóa JWT không được cấu hình hoặc quá ngắn (cần ít nhất 16 ký tự).");
            }
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Email),
                new Claim(JwtRegisteredClaimNames.NameId, user.Id.ToString()),
                new Claim("name", user.Name ?? string.Empty),
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()), // Đảm bảo luôn có id dạng số
                new Claim(ClaimTypes.NameIdentifier, user.Email ?? string.Empty), // Có thể loại bỏ nếu không cần
                new Claim(ClaimTypes.Role, user.Role ?? "user"),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddHours(1),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        // PUT: api/User/5
        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> PutUser(int id, UserUpdateDTO userUpdateDto)
        {
            var userIdFromToken = GetUserIdFromClaims();
            if (userIdFromToken == null)
            {
                return Unauthorized(new { message = "Token không hợp lệ hoặc thiếu thông tin người dùng." });
            }

            if (userIdFromToken != id /* && !User.IsInRole("admin") */)
            {
                return Forbid();
            }

            var user = await _context.Users.FindAsync(id);
            if (user == null)
                return NotFound(new { message = "Người dùng không tồn tại." });

            if (!string.IsNullOrEmpty(userUpdateDto.Email) && user.Email != userUpdateDto.Email && await _context.Users.AnyAsync(u => u.Email == userUpdateDto.Email && u.Id != id))
            {
                return BadRequest(new { message = "Email mới đã được sử dụng bởi tài khoản khác." });
            }

            if (!string.IsNullOrEmpty(userUpdateDto.Name))
            {
                user.Name = userUpdateDto.Name;
            }
            if (!string.IsNullOrEmpty(userUpdateDto.Email))
            {
                user.Email = userUpdateDto.Email;
            }
            if (!string.IsNullOrEmpty(userUpdateDto.Role) /* && User.IsInRole("admin") */)
            {
                user.Role = userUpdateDto.Role;
            }

            if (!string.IsNullOrEmpty(userUpdateDto.NewPassword))
            {
                if (string.IsNullOrEmpty(userUpdateDto.OldPassword))
                {
                    return BadRequest(new { message = "Cần cung cấp mật khẩu cũ để đổi mật khẩu mới." });
                }
                if (!BCrypt.Net.BCrypt.Verify(userUpdateDto.OldPassword, user.PasswordHash))
                    return BadRequest(new { message = "Mật khẩu cũ không đúng!" });

                user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(userUpdateDto.NewPassword);
            }

            _context.Entry(user).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserExists(id))
                    return NotFound();
                else
                    throw;
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Đã xảy ra lỗi khi cập nhật thông tin người dùng.", details = ex.Message });
            }

            return NoContent();
        }

        // DELETE: api/User/5
        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var userIdFromToken = GetUserIdFromClaims();
            if (userIdFromToken == null)
            {
                return Unauthorized(new { message = "Token không hợp lệ hoặc thiếu thông tin người dùng." });
            }

            if (userIdFromToken != id && !User.IsInRole("admin"))
            {
                return Forbid();
            }

            var user = await _context.Users.FindAsync(id);
            if (user == null)
                return NotFound(new { message = "Người dùng không tồn tại." });

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool UserExists(int id) =>
            _context.Users.Any(e => e.Id == id);

        private static UserDTO UserToDto(User user) =>
            new UserDTO
            {
                Id = user.Id,
                Name = user.Name,
                Email = user.Email,
                Role = user.Role
            };
    }
}