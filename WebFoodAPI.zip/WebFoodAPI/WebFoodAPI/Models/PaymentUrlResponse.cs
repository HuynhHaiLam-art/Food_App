﻿namespace WebFoodAPI.Models
{
    public class PaymentUrlResponse
    {
        public string PaymentUrl { get; set; }
    }
}
